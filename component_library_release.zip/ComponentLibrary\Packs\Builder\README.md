﻿# Builder Pack

## 组件

- `GridPlacementComponent`

## 依赖

- 无硬依赖

## 使用

- 用 `world_to_cell()` 将世界坐标映射到格子
- 用 `place(cell, payload)` 占用格子
- 用 `remove(cell)` 释放格子

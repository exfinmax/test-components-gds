# RPG Pack

## 组件

- `AttributeSetComponent`

## 依赖

- 无硬依赖

## 使用

- 用于管理基础属性 + 按来源叠加修改器
- 查询最终值：`get_attribute("attack")`

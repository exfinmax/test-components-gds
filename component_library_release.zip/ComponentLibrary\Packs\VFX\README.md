﻿# VFX Pack

## 组件

- `ImpactVFXComponent`

## 依赖

- 可选全局 `ObjectPool`

## 使用

- 用于受击特效、命中特效等即时表现。

﻿# UI Pack

## 组件

- `UIPageStateComponent`

## 依赖

- 无硬依赖

## 使用

- 用于通用页面状态切换（显示/隐藏/过渡）。

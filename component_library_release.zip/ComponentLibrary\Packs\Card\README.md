# Card Pack

## 组件

- `DeckDrawComponent`

## 依赖

- 无硬依赖
- 可选全局事件总线：`EventBus`

## 使用

- `set_deck(cards)` 设置卡组
- `draw(1)` 抽卡
- 监听 `card_drawn` 更新手牌 UI

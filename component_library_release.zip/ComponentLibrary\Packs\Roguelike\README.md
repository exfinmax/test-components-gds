# Roguelike Pack

## 组件

- `WeightedSpawnTableComponent`

## 依赖

- 无硬依赖

## 使用

- 配置 `entries`（id + weight + payload）
- 调用 `roll_entry()` 获取随机结果
- 可用 `set_seed()` 固定随机序列

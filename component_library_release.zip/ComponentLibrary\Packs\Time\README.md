﻿# Time Pack

## 组件

- `TimelineSwitchComponent`
- `TimeAbilityComponent`
- `TimeEnergyComponent`
- `TimeFragmentPickupComponent`
- `EchoTriggerPlateComponent`
- `RewindEchoBridgeComponent`

## 依赖

- 需要 `ComponentBase` / `CharacterComponentBase`
- 建议配合 `TimeController` 和 `LocalTimeDomain` 使用

## 使用

- 面向时间能力、时间机关和回放类玩法。

# Puzzle Pack

## 组件

- `SequenceSwitchComponent`

## 依赖

- 无硬依赖

## 使用

- 设置 `sequence`
- 通过 `input_step(step)` 推进输入
- 监听 `sequence_completed` 与 `sequence_failed`
